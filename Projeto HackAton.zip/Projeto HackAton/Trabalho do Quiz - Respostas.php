<?php
$host = "localhost";
$user = "root";
$pass = "";
$banco = "hackaton_grupo7";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$banco;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "SELECT * FROM perguntas_e_respostas WHERE id_pergunta = 2";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();

    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

} catch(PDOException $e) {
    die("Erro: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Quiz</title>
    <style>
        body { font-family: Arial; text-align: center; margin-top: 50px; }
        button { padding: 12px 20px; margin: 10px; cursor: pointer; }
    </style>
</head>
<body>

<h1>TechQuestion</h1>

<?php if ($usuario): ?>

    <h2><?= htmlspecialchars($usuario['PERGUNTA']); ?></h2>

    <button><?= htmlspecialchars($usuario['RESP_CORR']); ?></button>
    <button><?= htmlspecialchars($usuario['RESPOSTA_INC1']); ?></button>
    <button><?= htmlspecialchars($usuario['RESPOSTA_INC2']); ?></button>
    <button><?= htmlspecialchars($usuario['RESPOSTA_INC3']); ?></button>

<?php else: ?>
    <p>Nenhuma pergunta encontrada.</p>
<?php endif; ?>

</body>
</html>
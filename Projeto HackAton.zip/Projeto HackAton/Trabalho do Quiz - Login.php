<?php
$EmailUSU = $_POST['EMAIL'];
$SenhaUSU = $_POST['SENHA']
?>
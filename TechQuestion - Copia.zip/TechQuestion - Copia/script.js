let pontos = 0;

let perguntas = [];

let perguntaAtual = 0;

let tempo = 15;

let cronometro;

/* =========================
   LOGIN
========================= */

function entrar(){

    let nome = document.getElementById("nome").value;

    if(nome.trim() === ""){

        alert("Digite seu nome!");
        return;

    }

    localStorage.setItem("nomeJogador", nome);

    window.location.href = "menu.html";
}


/* =========================
   CADASTRO
========================= */

function cadastrar(){

    let nickname =
    document.getElementById("nickname").value;

    let email =
    document.getElementById("emailCadastro").value;

    let senha =
    document.getElementById("senhaCadastro").value;

    let confirmar =
    document.getElementById("confirmarSenha").value;


    /* CAMPOS VAZIOS */

    if(
        nickname.trim() === "" ||
        email.trim() === "" ||
        senha.trim() === "" ||
        confirmar.trim() === ""
    ){

        alert("Preencha todos os campos!");

        return;
    }


    /* EMAIL */

    if(!email.includes("@")){

        alert("Digite um email válido!");

        return;
    }


    /* SENHA */

    if(senha.length < 4){

        alert("A senha deve ter pelo menos 4 caracteres!");

        return;
    }


    /* CONFIRMAR SENHA */

    if(senha !== confirmar){

        alert("As senhas não coincidem!");

        return;
    }


    /* SALVAR USUARIO */

    let usuario = {

        nickname: nickname,

        email: email,

        senha: senha

    };



    alert("Cadastro realizado com sucesso!");


    window.location.href = "index.html";

}


/* =========================
   VOLTAR MENU
========================= */

function voltarMenu(){

    window.location.href = "menu.html";
}


/* =========================
   SALVAR PERGUNTA
========================= */

function salvarPergunta(){

    console.log("clicou");

    let perguntas = JSON.parse(localStorage.getItem("perguntas")) || [];

    let tempoPergunta = document.getElementById("tempoPergunta").value;
    let pergunta = document.getElementById("pergunta").value;

    let r1 = document.getElementById("r1").value;
    let r2 = document.getElementById("r2").value;
    let r3 = document.getElementById("r3").value;
    let r4 = document.getElementById("r4").value;

    let pontos = document.getElementById("pontos").value;

    let corretaInput = document.querySelector('input[name="correta"]:checked');

    if(
        pergunta.trim() === "" ||
        r1.trim() === "" ||
        r2.trim() === "" ||
        r3.trim() === "" ||
        r4.trim() === "" ||
        pontos.trim() === "" ||
        tempoPergunta.trim() === ""
    ){
        alert("Preencha todos os campos!");
        return;
    }

    if(!corretaInput){
        alert("Escolha a resposta correta!");
        return;
    }

    let novaPergunta = {
        pergunta: pergunta,
        respostas: [r1, r2, r3, r4],
        correta: Number(corretaInput.value),
        pontos: Number(pontos),
        tempo: Number(tempoPergunta)
    };

    perguntas.push(novaPergunta);

    localStorage.setItem("perguntas", JSON.stringify(perguntas));

    console.log(localStorage.getItem("perguntas"));

    alert("Pergunta salva!");
}


/* =========================
   LIMPAR CAMPOS
========================= */

function limparCampos(){

    document.getElementById("pergunta").value = "";

    document.getElementById("r1").value = "";
    document.getElementById("r2").value = "";
    document.getElementById("r3").value = "";
    document.getElementById("r4").value = "";
    let pontos = document.getElementById("pontos").value;


    let radios = document.querySelectorAll(
        'input[name="correta"]'
    );


    radios.forEach(function(radio){

        radio.checked = false;

    });
}


/* =========================
   INICIAR QUIZ
========================= */

function irQuiz(){

    let perguntas = JSON.parse(localStorage.getItem("perguntas")) || [];

    let indicePerguntaAtual = 0;

    let tempo = 0;
    let cronometro;

    
    if(perguntas.length === 0){

        alert("Crie pelo menos uma pergunta!");
        return;

    }


    let codigo = Math.floor(
        1000 + Math.random() * 9000
    );


    localStorage.setItem("codigoSala", codigo);

    localStorage.setItem(
        "perguntasSala",
        JSON.stringify(perguntas)
    );


    alert("Sala criada!\nCódigo: " + codigo);


    localStorage.removeItem("perguntas");
    window.location.href = "menu.html";
}

function iniciarTempo(){

    clearInterval(cronometro);

    tempo = Number(perguntas[perguntaAtual].tempo);

    document.getElementById("timer").innerHTML = "Timer: " + tempo;

    cronometro = setInterval(() => {

        tempo--;

        document.getElementById("timer").innerHTML = "Timer: " + tempo;

        if(tempo <= 0){

            clearInterval(cronometro);

            avancarSemResposta();

        }

    }, 1000);
}

/* =========================
   ENTRAR SALA
========================= */

function entrarSala(){

    let codigoDigitado =
        document.getElementById("codigoEntrada").value;

    let codigoSalvo =
        localStorage.getItem("codigoSala");


    if(codigoDigitado == codigoSalvo){

        window.location.href = "quiz.html";

    }else{

        alert("Código inválido!");

    }
}


/* =========================
   CARREGAR PERGUNTA
========================= */

function carregarPergunta(){

    if(
        !window.location.pathname.includes("quiz.html")
    ) return;


    perguntas = JSON.parse(
        localStorage.getItem("perguntasSala")
    ) || [];


    if(perguntas.length === 0){

        alert("Nenhuma pergunta encontrada!");

        window.location.href = "criarSala.html";

        return;

    }


    let pergunta = perguntas[perguntaAtual];


    document.getElementById("pergunta").innerHTML =
        pergunta.pergunta;

    document.getElementById("btn1").innerHTML =
        pergunta.respostas[0];

    document.getElementById("btn2").innerHTML =
        pergunta.respostas[1];

    document.getElementById("btn3").innerHTML =
        pergunta.respostas[2];

    document.getElementById("btn4").innerHTML =
        pergunta.respostas[3];

    iniciarTempo();
}


function avancarSemResposta(){

    alert("Tempo acabou!");

    let pergunta = perguntas[perguntaAtual];

    perguntaAtual++;

    if(perguntaAtual < perguntas.length){

        carregarPergunta();

    } else {

        finalizarQuiz(); // ou sua função de ranking final
    }
}
/* =========================
   VERIFICAR RESPOSTA
========================= */

function verificarResposta(resposta){

    clearInterval(cronometro);

    let pergunta = perguntas[perguntaAtual];


    if(resposta == pergunta.correta){

        pontos += Number(pergunta.pontos);

        alert("Resposta correta!");

    }else{

        alert("Resposta errada!");

    }


    perguntaAtual++;


    if(perguntaAtual < perguntas.length){

        carregarPergunta();

    }else{

        finalizarQuiz();

    }
}


/* =========================
   FINALIZAR QUIZ
========================= */

function finalizarQuiz(){

    let nome =
        localStorage.getItem("nomeJogador");

    let ranking = JSON.parse(
        localStorage.getItem("ranking")
    ) || [];


    ranking = [{
        nome: nome,
        pontos: pontos
    }];


    localStorage.setItem(
        "ranking",
        JSON.stringify(ranking)
    );


    window.location.href = "podio.html";
}


/* =========================
   CARREGAR PÓDIO
========================= */

function carregarPodio(){

    if(!window.location.pathname.includes("podio.html")) return;


    let ranking = JSON.parse(
        localStorage.getItem("ranking")
    ) || [];


    ranking.sort((a,b) => b.pontos - a.pontos);


    let podio = document.getElementById("podio");


    let classes = [

        "terceiro",

        "primeiro",

        "segundo"

    ];


    let posicoes = [

        "3º lugar",

        "1º lugar",

        "2º lugar"

    ];


    let ordem = [2,0,1];


    for(let i = 0; i < ordem.length; i++){

        let jogador = ranking[ordem[i]];

        if(!jogador) continue;


        podio.innerHTML += `

            <div class="colocacao ${classes[i]}">

                <div class="nomePodio">
                    ${jogador.nome}
                </div>

                <div class="fotoPerfil">
                    perfil
                </div>

                <h1>${posicoes[i]}</h1>

                <p>${jogador.pontos} pts</p>

            </div>

        `;
    }
}


/* =========================
   CARREGAMENTO AUTOMÁTICO
========================= */

window.onload = function(){

    carregarPergunta();

    carregarPodio();

};